package csc372mod4;

public abstract class Shape {
	protected double radius;
	protected double height;
	
	public Shape(double radius, double height)	{
		this.radius = radius;
		this.height = height;
	}
	
	public abstract double surfaceArea();
	public abstract double volume();
	
	@Override
	public String toString()	{
		return String.format("Radius: %.2f, Height: %.2f, ", radius, height);
	}
}