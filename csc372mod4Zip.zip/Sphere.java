package csc372mod4;

public class Sphere extends Shape {

	public Sphere(double radius) {
		super(radius, 0);
	}
	
	@Override
	public double surfaceArea()	{
		return 4 * Math.PI * Math.pow(radius, 3);
	}
	
	@Override
	public double volume()	{
		return (4.0 / 3) * Math.PI * Math.pow(radius, 3);
	}
	
	@Override
	public String toString()	{
		return super.toString() + String.format("Surface Area: %.2f, Volume: %.2f", surfaceArea(), volume());
	}

}